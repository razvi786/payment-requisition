



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="form-group row">
                <label for="id" class="col-md-4 col-form-label text-md-right">Request Id: <?php echo e($details->id); ?></label>
            </div>

            <div class="form-group row">
                <label for="status" class="col-md-4 col-form-label text-md-right">Status: <?php echo e($details->status); ?></label>
            </div>

            <div class="form-group row">
                <label for="feedback" class="col-md-4 col-form-label text-md-right">Feedback: <?php echo e($details->feedback); ?></label>
            </div>

            <div class="form-group row">
                <label for="view" class="col-md-4 col-form-label text-md-right"><a href="<?php echo e(env('HOSTNAME', 'http://localhost')); ?>/request/<?php echo e($details->id); ?>">View Request</a></label>
            </div>

        </div>
    </div>
</div>


<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/email/action.blade.php ENDPATH**/ ?>