<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center h4">All Users</div>

                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user-table', [])->html();
} elseif ($_instance->childHasBeenRendered('UH96IDa')) {
    $componentId = $_instance->getRenderedChildComponentId('UH96IDa');
    $componentTag = $_instance->getRenderedChildComponentTagName('UH96IDa');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UH96IDa');
} else {
    $response = \Livewire\Livewire::mount('user-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('UH96IDa', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/user/index.blade.php ENDPATH**/ ?>