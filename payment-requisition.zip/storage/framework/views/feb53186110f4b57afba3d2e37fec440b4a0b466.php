<?php $attributes = $attributes->exceptProps([
    'primaryKey' => null,
    'row' => null,
    'field' => null,
    'theme' => null
]); ?>
<?php foreach (array_filter(([
    'primaryKey' => null,
    'row' => null,
    'field' => null,
    'theme' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div wire:ignore.self
     x-data="{
       editable: false,
       id: '<?php echo e($row->{$primaryKey}); ?>',
       field: '<?php echo e($field); ?>',
       content: '<?php echo e(addslashes($row->{$field})); ?>'
    }">
    <div x-text="content"
         style="border-bottom: dotted 1px; cursor: pointer"
         x-show="!editable"
         x-on:dblclick="editable = true"
    ></div>
    <div x-cloak
         x-show="editable">
        <input
            type="text"
            x-on:dblclick="editable = true"
            x-on:keydown.enter="sendEventInputChanged($event, id, field); editable = false; content = $event.target.value"
            :class="{'cursor-pointer': !editable}"
            class="<?php echo e($theme->inputClass); ?> p-2"
            x-ref="editable"
            x-text="content"
            :value="content">
    </div>
</div>

<script>
    function sendEventInputChanged(event, id, field) {
        document.getElementsByClassName('message')[0].style.display = "none";
        window.livewire.emit('eventInputChanged', {
            id: id,
            value: event.target.value,
            field: field
        })
    }
</script>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/editable.blade.php ENDPATH**/ ?>