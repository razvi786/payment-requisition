<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header text-center h4">All Requests</div>

                <div class="card-body">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('all-request-table', [])->html();
} elseif ($_instance->childHasBeenRendered('Nq8WEdo')) {
    $componentId = $_instance->getRenderedChildComponentId('Nq8WEdo');
    $componentTag = $_instance->getRenderedChildComponentTagName('Nq8WEdo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Nq8WEdo');
} else {
    $response = \Livewire\Livewire::mount('all-request-table', []);
    $html = $response->html();
    $_instance->logRenderedChild('Nq8WEdo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/request/index.blade.php ENDPATH**/ ?>