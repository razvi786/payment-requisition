<?php $attributes = $attributes->exceptProps([
    'column' => null,
    'theme' => null,
    'sortField' => null,
    'sortDirection' => null,
    'enabledFilters' => null,
    'actions' => null,
    'dataField' => null,
]); ?>
<?php foreach (array_filter(([
    'column' => null,
    'theme' => null,
    'sortField' => null,
    'sortDirection' => null,
    'enabledFilters' => null,
    'actions' => null,
    'dataField' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php if($column->hidden === false): ?>
        <th class="<?php echo e($theme->table->thClass .' '. $column->headerClass); ?>"
            style="width: max-content;<?php if($column->sortable): ?>cursor:pointer; <?php endif; ?><?php echo e($theme->table->thStyle.' '. $column->headerStyle); ?>">
            <div class="<?php echo e($theme->cols->divClass); ?>">
                <?php if($column->sortable === true): ?>
                    <span class="text-base pr-2" style="font-size: 1rem !important;">
						<?php if($sortField !== $column->tableWithColumn): ?>
                            &#8597;
                        <?php elseif($sortDirection == 'desc'): ?>
                            &#8593;
                        <?php else: ?>
                            &#8595;
                        <?php endif; ?>
					</span>
                <?php endif; ?>
                <span
                    <?php if($column->sortable === true): ?>
                    wire:click="sortBy('<?php echo e($column->tableWithColumn != '' ? $column->tableWithColumn : ($column->dataField !='' ? $column->dataField : $column->field)); ?>')"
                    <?php endif; ?>
                >
                    <?php echo e($column->title); ?>

                </span>
            </div>
        </th>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/cols.blade.php ENDPATH**/ ?>