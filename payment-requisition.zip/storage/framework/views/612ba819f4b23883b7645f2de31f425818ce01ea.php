<?php $attributes = $attributes->exceptProps([
    'theme' => '',
    'inline' => null,
    'date' => null,
    'column' => null,
]); ?>
<?php foreach (array_filter(([
    'theme' => '',
    'inline' => null,
    'date' => null,
    'column' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php
        $customConfig = [];
        if (data_get($date, 'config')) {
            foreach (data_get($date, 'config') as $key => $value) {
                $customConfig[$key] = $value;
            }
        }
    ?>

    <div class="<?php echo e($theme->divClassNotInline); ?>" <?php if($inline): ?>  <?php endif; ?>>

        <?php if(!$inline): ?>
            <label for="input_<?php echo e(data_get($date, 'field')); ?>"
                   class="text-gray-700 dark:text-gray-300">
                <?php echo e(data_get($date, 'label')); ?>

            </label>
        <?php endif; ?>
        <input id="input_<?php echo e(data_get($date, 'field')); ?>"
               data-field="<?php echo e(data_get($date, 'dataField')); ?>"
               style="<?php echo e(data_get($column, 'headerStyle')); ?>"
               data-key="enabledFilters.date_picker.<?php echo e(data_get($date, 'dataField')); ?>"
               class="power_grid range_input_<?php echo e(data_get($date, 'dataField')); ?> <?php echo e($theme->inputClass); ?> <?php echo e(data_get($column, 'headerClass')); ?>"
               type="text"
               placeholder="<?php echo e(trans('livewire-powergrid::datatable.placeholders.select')); ?>"
               wire:model="filters.input_date_picker.<?php echo e(data_get($date, 'dataField')); ?>"
               wire:ignore>
    </div>
    <?php $__env->startPush('power_grid_scripts'); ?>
        <script type="application/javascript">
            flatpickr(document.getElementsByClassName('range_input_<?php echo e(data_get($date, 'dataField')); ?>'), {
                    mode: 'range',
                    defaultHour: 0,
                    ...<?php echo json_encode(config('livewire-powergrid.plugins.flat_piker.locales.'.app()->getLocale()), 15, 512) ?>,
                    <?php if(data_get($customConfig, 'only_future')): ?>
                    minDate: 'today',
                    <?php endif; ?>
                        <?php if(data_get($customConfig, 'no_weekends') === true): ?>
                    disable: [
                        function (date) {
                            return (date.getDay() === 0 || date.getDay() === 6);
                        }
                    ],
                    <?php endif; ?>
                    ...<?php echo json_encode($customConfig, 15, 512) ?>,
                    onClose: function (selectedDates, dateStr, instance) {
                        if (selectedDates.length > 0) {
                            window.livewire.emit('eventChangeDatePiker', {
                                selectedDates: selectedDates,
                                field: instance._input.attributes['data-field'].value,
                                values: instance._input.attributes['data-key'].value,
                                label: '<?php echo e(data_get($date, 'label')); ?>'
                            });
                        }
                    }
                }
            );
        </script>
    <?php $__env->stopPush(); ?>

</div>

<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/filters/date-picker.blade.php ENDPATH**/ ?>