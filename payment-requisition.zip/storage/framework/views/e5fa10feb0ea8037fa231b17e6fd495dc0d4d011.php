<?php $attributes = $attributes->exceptProps([
    'actions' => null,
    'theme' => null,
    'row' => null
]); ?>
<?php foreach (array_filter(([
    'actions' => null,
    'theme' => null,
    'row' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="w-full md:w-auto">
    <?php if(isset($actions) && count($actions) && $row !== ''): ?>
        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td class="pg-actions <?php echo e($theme->table->tdBodyClass); ?>"
                style="<?php echo e($theme->table->tdBodyStyle); ?>">
                <?php
                    $parameters = [];
                    foreach ($action->param as $param => $value) {
                        if (!empty($row->{$value})) {
                            $parameters[$param] = $row->{$value};
                        } else {
                            $parameters[$param] = $value;
                        }
                    }
                ?>

                <?php if($action->event !== ''): ?>
                    <a wire:click='$emit("<?php echo e($action->event); ?>", <?php echo json_encode($parameters, 15, 512) ?>)'
                       class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                        <?php echo $action->caption; ?>

                    </a>
                <?php elseif($action->view !== ''): ?>
                    <a wire:click='$emit("openModal", "<?php echo e($action->view); ?>", <?php echo json_encode($parameters, 15, 512) ?>)'
                       class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                        <?php echo $action->caption; ?>

                    </a>
                <?php else: ?>
                    <?php if(strtolower($action->method) !== ('get')): ?>
                        <form target="<?php echo e($action->target); ?>"
                              action="<?php echo e(route($action->route, $parameters)); ?>"
                              method="<?php echo e($action->target); ?>">
                            <?php echo method_field($action->method); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="<?php echo e(filled( $action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                                <?php echo $action->caption ?? ''; ?>

                            </button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route($action->route, $parameters)); ?>"
                           target="<?php echo e($action->target); ?>"
                           class="<?php echo e(filled($action->class) ? $action->class : $theme->actions->headerBtnClass); ?>">
                            <?php echo $action->caption; ?>

                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/actions.blade.php ENDPATH**/ ?>