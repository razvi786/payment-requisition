<link rel="stylesheet" href="<?php echo e(config('livewire-powergrid.plugins.bootstrap-select.css')); ?>" crossorigin="anonymous"/>
<style>
    .dropdown-toggle, .dropdown-item {
        padding-left: 15px;
        font-size: 0.85rem;
        color: #454444;
        padding-top: 8px;
        padding-bottom: 8px;
        display: inline-block;
        vertical-align: middle;
        line-height: normal;
    }
    .bootstrap-select {
        padding-left: 0 !important;
    }
</style>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/frameworks/bootstrap5/styles.blade.php ENDPATH**/ ?>