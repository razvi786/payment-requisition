<?php $attributes = $attributes->exceptProps([
    'theme' => null,
    'row' => null,
    'primaryKey' => null,
    'columns' => null
]); ?>
<?php foreach (array_filter(([
    'theme' => null,
    'row' => null,
    'primaryKey' => null,
    'columns' => null
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <?php $__currentLoopData = $columns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($column->hidden === false): ?>
            <td class="<?php echo e($theme->table->tdBodyClass . ' '.$column->bodyClass ?? ''); ?>"
                style=" <?php echo e($theme->table->tdBodyStyle . ' '.$column->bodyStyle ?? ''); ?>"
            >
                <?php if($column->editable === true): ?>
                    <span class="<?php echo e($theme->editable->spanClass); ?>">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.editable','data' => ['primaryKey' => $primaryKey,'row' => $row,'theme' => $theme->editable,'field' => $column->dataField != '' ? $column->dataField : $column->field]]); ?>
<?php $component->withName('livewire-powergrid::editable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['primaryKey' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($primaryKey),'row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row),'theme' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($theme->editable),'field' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($column->dataField != '' ? $column->dataField : $column->field)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.click-to-copy','data' => ['row' => $row,'field' => $row->{$column->field},'label' => $column->click_to_copy['label'] ?? null,'enabled' => $column->click_to_copy['enabled'] ?? false]]); ?>
<?php $component->withName('livewire-powergrid::click-to-copy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row),'field' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row->{$column->field}),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($column->click_to_copy['label'] ?? null),'enabled' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($column->click_to_copy['enabled'] ?? false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </span>

                <?php elseif(count($column->toggleable) > 0): ?>
                    <?php echo $__env->make($theme->toggleable->view, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                    <span class="flex justify-between">
                    <div>
                        <?php echo $row->{$column->field}; ?>

                    </div>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'livewire-powergrid::components.click-to-copy','data' => ['row' => $row,'field' => $row->{$column->field},'label' => data_get($column->clickToCopy, 'label') ?? null,'enabled' => data_get($column->clickToCopy, 'enabled') ?? false]]); ?>
<?php $component->withName('livewire-powergrid::click-to-copy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['row' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row),'field' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($row->{$column->field}),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(data_get($column->clickToCopy, 'label') ?? null),'enabled' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(data_get($column->clickToCopy, 'enabled') ?? false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </span>
                <?php endif; ?>
            </td>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/row.blade.php ENDPATH**/ ?>