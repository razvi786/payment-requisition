<?php if(!is_array($data)): ?>
    <div class="d-flex justify-content-between">

        <?php if($perPageInput): ?>
            <div class="d-flex justify-content-center">
                <div>
                    <label class="col-12 col-sm-6 col-md-6"
                           style="width: 120px;">
                        <select wire:model="perPage" class="form-select"
                                style="width: 110px;">
                            <?php $__currentLoopData = $perPageValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>">
                                    <?php if($value == 0): ?>
                                        <?php echo e(trans('livewire-powergrid::datatable.labels.all')); ?>

                                    <?php else: ?> <?php echo e($value); ?>

                                    <?php endif; ?>
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </label>
                </div>
                <span
                    style="padding-top: 8px;padding-left: 6px;">
                    <?php echo e(trans('livewire-powergrid::datatable.labels.results_per_page')); ?>

                </span>
            </div>
        <?php endif; ?>
        <div>
            <?php echo $data->links(powerGridThemeRoot().'.pagination'); ?>

        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\Users\ehsan\Desktop\payment-requisition\resources\views/vendor/livewire-powergrid/components/frameworks/bootstrap5/footer.blade.php ENDPATH**/ ?>