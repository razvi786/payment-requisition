@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <p class="display-4 text-center">Welcome Page</p>
        </div>
    </div>

</div>
@endsection
