<?php return array (
  'all-request-table' => 'App\\Http\\Livewire\\AllRequestTable',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);